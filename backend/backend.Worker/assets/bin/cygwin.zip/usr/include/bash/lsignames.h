/* This file was automatically created by ./mksignames.
   Do not edit.  Edit support/mksignames.c instead. */

/* A translation list so we can be polite to our users. */
char *signal_names[NSIG + 4] = {
    "EXIT",
    "SIGHUP",
    "SIGINT",
    "SIGQUIT",
    "SIGILL",
    "SIGTRAP",
    "SIGABRT",
    "SIGEMT",
    "SIGFPE",
    "SIGKILL",
    "SIGBUS",
    "SIGSEGV",
    "SIGSYS",
    "SIGPIPE",
    "SIGALRM",
    "SIGTERM",
    "SIGURG",
    "SIGSTOP",
    "SIGTSTP",
    "SIGCONT",
    "SIGCHLD",
    "SIGTTIN",
    "SIGTTOU",
    "SIGIO",
    "SIGXCPU",
    "SIGXFSZ",
    "SIGVTALRM",
    "SIGPROF",
    "SIGWINCH",
    "SIGPWR",
    "SIGUSR1",
    "SIGUSR2",
    "SIGRTMAX",
    "DEBUG",
    "ERR",
    "RETURN",
    (char *)0x0
};

#define initialize_signames()

