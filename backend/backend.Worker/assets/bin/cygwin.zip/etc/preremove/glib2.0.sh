rm -f /usr/lib/gio/modules/giomodule.cache /usr/share/glib-2.0/schemas/gschemas.compiled
